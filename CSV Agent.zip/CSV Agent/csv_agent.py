import os
import sys
import csv
import json
import subprocess
import numpy as np
from sentence_transformers import SentenceTransformer
import faiss
import glob
from typing import List, Dict, Any


# Loads Startupticker, Crunchbase, and SOGC (sample) CSV data as the agent's knowledge base
def load_csv_files(directory: str = "data") -> List[Dict[str, Any]]:
    """
    Loads all CSV files from the specified directory.
    Each CSV file is processed and its rows are converted to structured data entries.
    """
    all_entries = []
    
    if not os.path.exists(directory):
        print(f"Warning: Directory '{directory}' not found. Creating it...")
        os.makedirs(directory)
        return all_entries
    
    # Gets all CSV files in "directory"
    csv_files = glob.glob(os.path.join(directory, "*.csv"))
    
    if not csv_files:
        print(f"Warning: No CSV files found in '{directory}'")
        return all_entries
    
    for csv_file in csv_files:
        file_name = os.path.basename(csv_file)
        print(f"Loading: {file_name}")
        
        try:
            with open(csv_file, "r", encoding="utf-8") as f:
                reader = csv.DictReader(f)
                for row_idx, row in enumerate(reader):
                    entry = {
                        "source_file": file_name,
                        "row_id": row_idx,
                        "data": row
                    }
                    all_entries.append(entry)
        except Exception as e:
            print(f"Error loading {file_name}: {str(e)}")
    
    print(f"Loaded {len(all_entries)} entries from {len(csv_files)} CSV files")
    return all_entries

# Function to convert CSV entries to formatted text for embedding
def format_csv_entries(entries: List[Dict[str, Any]]) -> List[str]:
    formatted_texts = []
    
    for entry in entries:
        source_file = entry["source_file"]
        row_id = entry["row_id"]
        data = entry["data"]
        
        data_points = []
        for key, value in data.items():
            if value and str(value).strip(): 
                data_points.append(f"{key}: {value}")
        
        text = f"Source: {source_file}, Row: {row_id}\n" + "\n".join(data_points)
        formatted_texts.append(text)
    
    return formatted_texts

# Creates embeddings for the given texts and builds a FAISS index
def setup_search_index(texts: List[str]):
    print("🔍 Creating embeddings and search index...")
    
    model = SentenceTransformer("all-MiniLM-L6-v2") # Transformer model is set here
    
    embeddings = model.encode(texts)
    
    dimension = embeddings[0].shape[0]
    index = faiss.IndexFlatL2(dimension)
    index.add(np.array(embeddings).astype("float32"))
    
    return model, index

# Detects the nature of the question as "statistical", "comparison", "trend", "lookup", or "general"
def classify_query_type(question: str) -> str:
    q = question.lower()
    
    if any(term in q for term in ["average", "mean", "median", "sum", "total", "count", "how many"]):
        return "statistical"
    
    elif any(term in q for term in ["compare", "difference", "versus", "vs", "against"]):
        return "comparison"
    
    elif any(term in q for term in ["trend", "over time", "increase", "decrease", "growth"]):
        return "trend"
    
    elif any(term in q for term in ["find", "search", "where", "which", "who has", "specific"]):
        return "lookup"
        
    else:
        return "general"

# Uses Ollama to run Llama3.2 (can be replaced with other models)
def generate_with_ollama(prompt: str, model: str = "llama3.2") -> str:
    try:
        result = subprocess.run(
            ["ollama", "run", model],
            input=prompt.encode("utf-8"),
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        return result.stdout.decode("utf-8").strip()
    except Exception as e:
        return f"Error generating response: {str(e)}"

def answer_from_csv(question: str, model, index: faiss.Index, texts: List[str], 
                   original_entries: List[Dict[str, Any]], k: int = 5) -> str:
 
    query_vec = model.encode([question])
    
    D, I = index.search(np.array(query_vec).astype("float32"), k=k)
    
    results = [texts[i] for i in I[0] if i < len(texts)]
    
    retrieved_entries = [original_entries[i] for i in I[0] if i < len(original_entries)]
    
    if not results:
        return "I don't have enough information to answer that question."
    
    context = "\n\n---\n\n".join(results)
    
    query_type = classify_query_type(question)
    
    # Sets the appropriate prompt template based on query type
    if query_type == "statistical":
        prompt_template = """
You are a data analyst assistant that helps answer statistical questions about CSV data.

Use ONLY the following data to answer the question. Calculate averages, totals, counts, or other statistics as needed. 
If you can't find the exact information, say so. Don't make up information that's not in the data.

DATA:
{context}

Question: {question}

Analyze the data systematically:
1. Identify the relevant columns and values
2. Perform any necessary calculations
3. Present the results clearly

Answer:
"""
    elif query_type == "comparison":
        prompt_template = """
You are a data analyst assistant that helps compare values in CSV data.

Use ONLY the following data to answer the question. Compare the requested items, noting similarities and differences.
If you can't find information about both items to compare, say so. Don't make up information.

DATA:
{context}

Question: {question}

Comparison approach:
1. Identify the items being compared
2. Extract relevant attributes for each
3. Note key similarities and differences
4. Summarize the comparison

Answer:
"""
    elif query_type == "trend":
        prompt_template = """
You are a data analyst assistant that helps identify trends in CSV data.

Use ONLY the following data to answer the question. Look for patterns over time or within categories.
Be clear about the limitations of the data provided. Don't invent trends that aren't supported.

DATA:
{context}

Question: {question}

Trend analysis:
1. Identify relevant time periods or categories
2. Note patterns in the data
3. Describe any trends you can identify
4. Mention any limitations in the available data

Answer:
"""
    elif query_type == "lookup":
        prompt_template = """
You are a data lookup assistant that helps find specific information in CSV data.

Use ONLY the following data to answer the question. Find the exact information requested.
If the information isn't in the data provided, clearly state that.

DATA:
{context}

Question: {question}

Lookup approach:
1. Identify the specific information being requested
2. Search for exact matches or relevant entries
3. Present the findings clearly
4. If information is missing, say so clearly

Answer:
"""
    else:  # General
        prompt_template = """
You are a data assistant that helps answer questions based on CSV data.

Use ONLY the following data to answer the question. Be specific and provide details from the data.
If the answer isn't in the data provided, clearly state that you don't have enough information.

DATA:
{context}

Question: {question}

Answer:
"""
    
    prompt = prompt_template.format(context=context, question=question)
    
    return generate_with_ollama(prompt)

# Main function to run the RAG agent with the CSV knowledge base.
def main():
    print("\n📊 CSV-Based RAG Agent")
    print("Loading CSV files from the 'data' directory...")
    
    csv_entries = load_csv_files()
    
    if not csv_entries:
        print("Error: No CSV data found. Please add CSV files to the 'data' directory.")
        return
    
    formatted_texts = format_csv_entries(csv_entries)
    
    model, index = setup_search_index(formatted_texts)
    
    print("\n🧠 CSV Agent is ready!")
    print("Type your question about the CSV data, or type 'exit' to quit.")
    
    while True:
        question = input("\nYou: ")
        
        if question.lower() in ["exit", "quit", "q"]:
            print("Goodbye!")
            break
        
        answer = answer_from_csv(question, model, index, formatted_texts, csv_entries)
        
        print("\n🤖 Answer:\n", answer)

if __name__ == "__main__":
    main()