# streamlit run Final.py

import streamlit as st
import pandas as pd
import numpy as np
import plotly.express as px
import plotly.graph_objects as go
from sqlalchemy import create_engine
import requests
from bs4 import BeautifulSoup
from datetime import datetime
from sentence_transformers import SentenceTransformer
from sklearn.metrics.pairwise import cosine_similarity
from nltk.corpus import stopwords
from deep_translator import GoogleTranslator

import json
import csv
import subprocess
import faiss

st.set_page_config(
    page_title="Swiss Startup Analyzer",
    page_icon="🇨🇭",
    layout="wide"
)

@st.cache_resource
def get_db_connection():
    # my password is masked
    connection_string = "mysql+pymysql://root:<password placeholder>@localhost:3306/startupticker"
    engine = create_engine(connection_string)
    return engine

@st.cache_resource
def load_models():
    return SentenceTransformer('all-MiniLM-L6-v2')

@st.cache_data
def scrape_article(url):
    response = requests.get(url, timeout=10)
    soup = BeautifulSoup(response.text, 'html.parser')
        
    # title
    title = soup.find('h1').text.strip() if soup.find('h1') else "No title found"
        
    # intro
    intro = soup.find('div', class_='item-intro')
    if intro:
        paragraphs = intro.find_all('p')
        intro_text = ' '.join([p.text.strip() for p in paragraphs])
    else:
        intro_text = "No content found"
        
    return {
        'title': title,
        'intro': intro_text
    }

@st.cache_data
def load_startups_data(_engine):
    query = "SELECT * FROM company"
    return pd.read_sql(query, con=_engine)

@st.cache_data
def load_deals_data(_engine):
    query = "SELECT * FROM deal"
    return pd.read_sql(query, con=_engine)

@st.cache_data
def load_articles_data(deals_df):
    urls = deals_df['url'].dropna().unique()
    filtered_urls = [url for url in urls if url.startswith("https://www.startupticker.ch")]
    
    sample_size = 300 # to make it run faster
    sample_urls = np.random.choice(filtered_urls, sample_size, replace=False)
    
    articles = []
    for url in sample_urls:
        article_data = scrape_article(url)
        article_data['url'] = url
        articles.append(article_data)
    
    return pd.DataFrame(articles)

@st.cache_data
def semantic_search(query, articles_df, _sentence_model, top_n=5):
    
    query_embedding = _sentence_model.encode([query])[0]
    article_embeddings = _sentence_model.encode(articles_df['intro'].tolist())
    similarities = cosine_similarity([query_embedding], article_embeddings)[0]
    
    result_df = articles_df.copy()
    result_df['similarity'] = similarities
    
    return result_df.sort_values('similarity', ascending=False).head(top_n)


@st.cache_data
def translate_text(text):
    if not text or not isinstance(text, str) or len(text.strip()) == 0:
        return text
        
    max_chunk_size = 4500  
    if len(text) <= max_chunk_size:
        return GoogleTranslator(target='en').translate(text)

    chunks = [text[i:i+max_chunk_size] for i in range(0, len(text), max_chunk_size)]
    translated_chunks = []
            
    for chunk in chunks:
        translated = GoogleTranslator(target='en').translate(chunk)
        translated_chunks.append(translated) 
    return " ".join(translated_chunks)

    
@st.cache_data
def process_and_translate_articles(articles_df):
    articles_df['original_intro'] = articles_df['intro']
    articles_df['original_title'] = articles_df['title']
    
    translation_progress = st.progress(0)
    st.write("Translating articles...")
    
    total_articles = len(articles_df)
    translated_titles = []
    translated_intros = []
    
    for i, (_, row) in enumerate(articles_df.iterrows()):
        progress_pct = min(1.0, (i + 1) / total_articles)
        translation_progress.progress(progress_pct)
        
        title = row['title'] if isinstance(row['title'], str) else ""
        intro = row['intro'] if isinstance(row['intro'], str) else ""
        
        translated_title = translate_text(title)
        translated_intro = translate_text(intro)
        
        translated_titles.append(translated_title)
        translated_intros.append(translated_intro)
    
    articles_df['translated_title'] = translated_titles
    articles_df['translated_intro'] = translated_intros
    
    articles_df['title'] = articles_df['translated_title']
    articles_df['intro'] = articles_df['translated_intro']
    
    return articles_df


def plot_funding_by_industry(df):
    industry_funding = df.groupby('industry')['funded'].sum().reset_index()
    industry_funding = industry_funding.sort_values('funded', ascending=False).head(5)
    
    fig = px.bar(
        industry_funding,
        x='industry',
        y='funded',
        title='Top 5 Industries by Number of Fundings',
        color='industry',
        labels={'industry': 'Industry', 'funded': 'Number of Fundings'}
    )
    fig.update_layout(xaxis_tickangle=-45)
    return fig


def plot_funding_over_time(df):
    df['date_of_funding_round'] = pd.to_datetime(df['date_of_funding_round'], errors='coerce')
    yearly_funding = df.groupby(df['date_of_funding_round'].dt.year)['amount'].sum().reset_index()
    yearly_funding.columns = ['Year', 'Amount']
    
    fig = px.line(
        yearly_funding, 
        x='Year', 
        y='Amount',
        title='Funding Over Time',
        labels={'Amount': 'Total Funding (CHF)', 'Year': 'Year'},
        markers=True
    )
    return fig


def plot_gender_distribution(df):
    gender_counts = df['gender_ceo'].value_counts().reset_index()
    gender_counts.columns = ['Gender', 'Count']
    
    fig = px.pie(
        gender_counts,
        values='Count',
        names='Gender',
        title='CEO Gender Distribution',
        color='Gender',
        color_discrete_map={'Male': '#636EFA', 'Female': '#EF553B', 'Unknown': '#FECB52'}
    )
    fig.update_traces(textposition='inside', textinfo='percent+label')
    return fig


def plot_canton_distribution(df):
    canton_counts = df['canton'].value_counts().reset_index()
    canton_counts.columns = ['Canton', 'Count']
    canton_counts = canton_counts.sort_values('Count', ascending=False).head(5)
    
    fig = px.bar(
        canton_counts,
        x='Canton',
        y='Count',
        title='Top 5 Cantons by Number of Startups',
        color='Canton',
        labels={'Canton': 'Canton', 'Count': 'Number of Startups'}
    )
    return fig


def plot_phase_distribution(df):
    phase_counts = df['phase'].value_counts().reset_index()
    phase_counts.columns = ['Phase', 'Count']
    
    fig = px.pie(
        phase_counts,
        values='Count',
        names='Phase',
        title='Distribution of Investment Phases',
        hole=0.4
    )
    fig.update_traces(textposition='inside', textinfo='percent+label')
    return fig


@st.cache_resource
def load_sentence_transformer():
    return SentenceTransformer("all-MiniLM-L6-v2")

@st.cache_data
def load_articles():
    filename = "startupticker_articles.json"
    with open(filename, "r", encoding="utf-8") as f:
        return json.load(f)

@st.cache_resource
def build_faiss_index(articles):
    model = load_sentence_transformer()
    
    texts = [
        f"{article.get('title', '')}. {article.get('intro', '')}"
        for article in articles
    ]
    embeddings = model.encode(texts)

    dim = embeddings[0].shape[0]
    index = faiss.IndexFlatL2(dim)
    index.add(np.array(embeddings).astype("float32"))
    
    return index, texts, model

def classify_use_case(question):
    q = question.lower()
    if any(word in q for word in ["compare", "benchmark", "performance", "average", "portfolio"]):
        return "benchmarking"
    elif any(word in q for word in ["trend", "growth", "increase", "decline", "pattern", "rise", "fall", "recovery"]):
        return "trend"
    else:
        return "general"

def generate_with_ollama(prompt):
    result = subprocess.run(
            ["ollama", "run", "llama3.2"],
            input=prompt.encode("utf-8"),
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=30)
    return result.stdout.decode("utf-8").strip()

def ask_question(question, faiss_index, texts, model):
    if not question.strip():
        return "Please enter a question."

    query_vec = model.encode([question])

    D, I = faiss_index.search(np.array(query_vec).astype("float32"), k=3)
    results = [texts[i] for i in I[0] if i < len(texts)]
    
    context = "\n\n".join(results)
    use_case = classify_use_case(question)

    if use_case == "benchmarking":
        prompt_template = """
You are a benchmarking assistant for the Swiss startup ecosystem.

Use the context below to compare the performance of a startup or portfolio to the rest of the ecosystem.
Mention if the startup(s) are above or below average, and if relevant, compare within their sector.

Context:
{context}

Question: {question}
Answer:
"""
    elif use_case == "trend":
        prompt_template = """
You are a startup trend analyst with expertise in funding, growth, and sector dynamics.

Use the context below to detect trends in the Swiss startup ecosystem. Look for patterns in investment amounts, sectors, growth, or startup activity.

Context:
{context}

Question: {question}
Answer:
"""
    else:
        prompt_template = """
You are an expert on the Swiss startup ecosystem.

Use the context below to answer the question in a helpful and relevant way. If the context doesn't contain the information needed, acknowledge this and provide general information about Swiss startups that might be helpful.

Context:
{context}

Question: {question}
Answer:
"""
    
    prompt = prompt_template.format(context=context, question=question)
    
    with st.spinner("Generating response..."):
        return generate_with_ollama(prompt)


def main():
    st.title("🇨🇭 Swiss Startup Ecosystem Analyzer")
    
    st.sidebar.image("startupticker-logo-animated.gif", use_container_width=True)
    #st.logo("startupticker-logo-animated.gif", size="large")
    
    engine = get_db_connection()
    startups_df = load_startups_data(engine)
    deals_df = load_deals_data(engine)
    
    if 'chat_history' not in st.session_state:
        st.session_state.chat_history = []
            
    if 'faiss_index_initialized' not in st.session_state:
        with st.spinner("Setting up the assistant... This may take a minute."):
            articles = load_articles()
            faiss_index, texts, model = build_faiss_index(articles)
            st.session_state.faiss_index = faiss_index
            st.session_state.texts = texts
            st.session_state.model = model
            st.session_state.faiss_index_initialized = True
            st.success("Assistant is ready!")
    
    sentence_model_1 = load_models()
    
    tab1, tab2, tab3 = st.tabs(["Startup Ecosystem", "Semantic Search", "AI Assistant"])
    
    with tab1:
        st.header("Swiss Startup Ecosystem Dashboard")
        
        with st.container():
            st.subheader("Filters")
    
            col1, col2 = st.columns(2)
            with col1:
                industries = ['All'] + sorted(startups_df['industry'].dropna().unique().tolist())
                selected_industry = st.selectbox("Industry", industries)

                cantons = ['All'] + sorted(startups_df['canton'].dropna().unique().tolist())
                selected_canton = st.selectbox("Canton", cantons)

            with col2:
                phases = ['All'] + sorted(deals_df['phase'].dropna().unique().tolist())
                selected_phase = st.selectbox("Investment Phase", phases)

                min_year = int(startups_df['year'].min()) 
                max_year = int(startups_df['year'].max())
                selected_years = st.slider(
                    "Year Range", 
                    min_value=min_year,
                    max_value=max_year,
                    value=(min_year, max_year)
                )

        
        filtered_startups = startups_df.copy()
        
        if selected_industry != 'All':
            filtered_startups = filtered_startups[filtered_startups['industry'] == selected_industry]
            
        if selected_canton != 'All':
            filtered_startups = filtered_startups[filtered_startups['canton'] == selected_canton]
        
        filtered_startups = filtered_startups[
            (filtered_startups['year'] >= selected_years[0]) & 
            (filtered_startups['year'] <= selected_years[1])
        ]
        
        filtered_deals = deals_df.copy()
        
        if selected_phase != 'All':
            filtered_deals = filtered_deals[filtered_deals['phase'] == selected_phase]
        
        st.subheader(f"Found {len(filtered_startups)} startups matching your criteria")
        
        if selected_industry == 'All':
            fig1 = plot_funding_by_industry(filtered_startups)
            st.plotly_chart(fig1, use_container_width=True)
        
        fig2 = plot_funding_over_time(filtered_deals)
        st.plotly_chart(fig2, use_container_width=True)

        fig3 = plot_gender_distribution(filtered_startups)
        st.plotly_chart(fig3, use_container_width=True)
        
        if selected_canton == 'All':
            fig5 = plot_canton_distribution(filtered_startups)
            st.plotly_chart(fig5, use_container_width=True)

        if selected_phase == 'All':
            fig6 = plot_phase_distribution(filtered_deals)
            st.plotly_chart(fig6, use_container_width=True)

        st.subheader("AI Insights")
    
        col1, col2, col3 = st.columns(3)
        
        with col1:
            if selected_industry != 'All':
                industry_question = f"What are the main trends for {selected_industry} startups in Switzerland?"
                if st.button("Show Industry Trends", key="tab1_industry_trends"):
                    if st.session_state.get('faiss_index_initialized', False):
                        with st.spinner("Generating insights..."):
                            response = ask_question(
                                industry_question, 
                                st.session_state.faiss_index, 
                                st.session_state.texts, 
                                st.session_state.model)
                            st.info(response)
            
        with col2:
            if selected_canton != 'All':
                canton_question = f"How does the startup ecosystem in {selected_canton} compare to other cantons?"
                if st.button("Compare Canton Performance", key="tab1_canton_compare"):
                    if st.session_state.get('faiss_index_initialized', False):
                        with st.spinner("Generating insights..."):
                            response = ask_question(
                                canton_question, 
                                st.session_state.faiss_index, 
                                st.session_state.texts, 
                                st.session_state.model)
                            st.info(response)
    
        with col3:
            if selected_phase != 'All':
                phase_question = f"What are the success factors for startups in the {selected_phase} phase?"
                if st.button("Success Factors Analysis", key="tab1_phase_analysis"):
                    if st.session_state.get('faiss_index_initialized', False):
                        with st.spinner("Generating insights..."):
                            response = ask_question(
                                phase_question, 
                                st.session_state.faiss_index, 
                                st.session_state.texts, 
                                st.session_state.model)
                            st.info(response)
        
    with tab2:
        st.header("Startup News Semantic Search")

        st.info("This feature allows you to search for startup news based on semantic similarity using articles related to Swiss startups.")

        with st.spinner("Loading and processing news articles... This may take a few minutes."):
            articles_df = load_articles_data(deals_df)
            articles_df = process_and_translate_articles(articles_df)
            st.success(f"Loaded and processed all the news articles.")
            search_query = st.text_input("Enter your search query:")
                
            if search_query:
                holder = []
                with st.spinner("Searching for relevant articles..."):
                    search_results = semantic_search(search_query, articles_df, sentence_model_1)
                    st.subheader("Top 5 Most Relevant News Articles")
                    for i, (_, article) in enumerate(search_results.iterrows()):
                        holder.append(article['title'])
                        with st.expander(f"{i+1}. {article['title']}"):
                            st.markdown("### Article Intro")
                            st.markdown(f"{article['intro']}")
                            st.markdown("---")
                            st.markdown(f"Read the full article here({article['url']})")
                            
        if search_query and st.session_state.get('faiss_index_initialized', False):
            st.subheader("AI Summary")
            summary_question = f"Based on Swiss startup news, summarize information about: {search_query} and the papers {holder}."
            if st.button("Generate AI Summary", key="tab2_ai_summary"):
                with st.spinner("Generating summary..."):
                    response = ask_question(
                        summary_question, 
                        st.session_state.faiss_index, 
                        st.session_state.texts, 
                        st.session_state.model)
                    st.info(response)
                            
    with tab3:
        st.header("Swiss Startup Assistant")
        st.subheader("Ask questions about the Swiss startup ecosystem")

        with st.expander("About this assistant"):
            st.markdown("""
            This AI assistant is trained on Swiss startup news and data. It can answer questions about:
            - Benchmarking startups against the Swiss ecosystem
            - Identifying trends in funding, sectors, and growth
            - General information about Swiss startups
            """)
        
        for message in st.session_state.chat_history:
            with st.chat_message(message["role"]):
                st.markdown(message["content"])
        
        
        if prompt := st.chat_input("Ask a question about Swiss startups"):
            st.session_state.chat_history.append({"role": "user", "content": prompt})
            
            with st.chat_message("user"):
                st.markdown(prompt)
            
            with st.chat_message("assistant"):
                response = ask_question(
                    prompt, 
                    st.session_state.faiss_index, 
                    st.session_state.texts, 
                    st.session_state.model
                    )
                st.markdown(response)
                
            st.session_state.chat_history.append({"role": "assistant", "content": response})
                    
        st.subheader("Key Questions")
        
        col1, col2 = st.columns(2)
        
        with col1:
            if st.button("Identify Investment Opportunities", key="tab2_opportunities"):
                opportunity_question = "What are the most promising investment opportunities in the Swiss startup ecosystem right now?"
                with st.spinner("Analyzing opportunities..."):
                    response = ask_question(
                        opportunity_question, 
                        st.session_state.faiss_index, 
                        st.session_state.texts, 
                        st.session_state.model)
                    st.info(response)
                
        with col2:
            if st.button("Recent Success Stories", key="tab2_success"):
                success_question = "What are some recent success stories of Swiss startups?"
                with st.spinner("Finding success stories..."):
                    response = ask_question(
                        success_question, 
                        st.session_state.faiss_index, 
                        st.session_state.texts, 
                        st.session_state.model)
                    st.info(response)
                            

if __name__ == "__main__":
    main()