import os
import sys
import json
import csv
import subprocess
import numpy as np
from sentence_transformers import SentenceTransformer
import faiss


# Loads articles (web-scrapped in JSON format) as the agent's knowledge base
def load_articles():
    filename = "startupticker_articles.json"  # Ensure your scraped articles are stored here.
    if os.path.exists(filename):
        with open(filename, "r", encoding="utf-8") as f:
            return json.load(f)
    else:
        print("Error: JSON cannot be imported.")
        return []

# Structured data to support the JSON-based knowledge base (optional, not deployed)
def load_structured_data(filename):
    data_points = []
    if os.path.exists(filename):
        with open(filename, "r", encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                entry = (
                    f"FACT - Metric: {row.get('metric_name', '')}; "
                    f"Value: {row.get('value', '')}; "
                    f"Source: {row.get('source', '')}; "
                    f"Date: {row.get('date', '')}"
                )
                data_points.append(entry)
    return data_points

print("🔍 Loading articles...")
articles = load_articles()

# Construct text documents for embeddings from the JSON articles
texts = [
    f"{article.get('title', '')}. {article.get('intro', '')}"
    for article in articles
]
# Uncomment next line to incorporate structured facts as additional context
# texts = texts + structured_facts

# Loads the sentence transformer model to encode texts
model = SentenceTransformer("all-MiniLM-L6-v2")
embeddings = model.encode(texts)

# Builds a FAISS index using L2 distance
index = faiss.IndexFlatL2(embeddings[0].shape[0])
index.add(np.array(embeddings).astype("float32"))

# Detects the nature of the question as "benchmarking" or "trend analysis"
def classify_use_case(question):
    """
    Returns 'benchmarking' if the question involves comparisons or performance, 
    Returns 'trend' for trend-related queries
    Returns 'general' for all other cases.
    """
    q = question.lower()
    if any(word in q for word in ["compare", "benchmark", "performance", "average", "portfolio"]):
        return "benchmarking"
    elif any(word in q for word in ["trend", "growth", "increase", "decline", "pattern", "rise", "fall", "recovery"]):
        return "trend"
    else:
        return "general"

# Uses Ollama to run Llama3.2 (can be replaced with other models)
def generate_with_ollama(prompt):
    """
    Calls the Ollama CLI to run the LLaMA model using the provided prompt.
    Adjusts the command arguments as necessary to match the caller's environment.
    """
    result = subprocess.run(
        ["ollama", "run", "llama3.2"],
        input=prompt.encode("utf-8"),
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE
    )
    return result.stdout.decode("utf-8").strip()

def ask_question(question):
    """
    Encodes the question, retrieves the top 3 most relevant texts from the FAISS index,
    builds a prompt using the retrieved context from the JSON-based knowledge base, and then sends it to Ollama.
    """
    query_vec = model.encode([question])
    D, I = index.search(np.array(query_vec).astype("float32"), k=3)
    results = [texts[i] for i in I[0] if i < len(texts)]

    if not results:
        return "Sorry, I couldn't find anything relevant."

    context = "\n\n".join(results)
    use_case = classify_use_case(question)

    if use_case == "benchmarking":
        prompt_template = """
You are a benchmarking assistant for the Swiss startup ecosystem.

Use the context below to compare the performance of a startup or portfolio to the rest of the ecosystem.
Mention if the startup(s) are above or below average, and if relevant, compare within their sector.

Context:
{context}

Question: {question}
Answer:
"""
    elif use_case == "trend":
        prompt_template = """
You are a startup trend analyst with expertise in funding, growth, and sector dynamics.

Use the context below to detect trends in the Swiss startup ecosystem. Look for patterns in investment amounts, sectors, growth, or startup activity.

Context:
{context}

Question: {question}
Answer:
"""
    else:
        prompt_template = """
Use the context below to answer the question in a helpful and relevant way.

Context:
{context}

Question: {question}
Answer:
"""
    prompt = prompt_template.format(context=context, question=question)
    return generate_with_ollama(prompt)

# Chat interaction interface activated while runing the RAG agent with the article knowledge base.
if __name__ == "__main__":
    print("\n🧠 RAG Chatbot Prototype Ready (Ollama + LLaMA 3.2)")
    print("Type your question, or type 'exit' to quit.")
    while True:
        q = input("\nYou: ")
        if q.lower() in ["exit", "quit"]:
            break
        answer = ask_question(q)
        print("\n🤖 Answer:\n", answer)