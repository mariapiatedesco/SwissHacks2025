CREATE DATABASE IF NOT EXISTS startupticker;
USE startupticker;


DROP TABLE IF EXISTS deal;
DROP TABLE IF EXISTS company;


CREATE TABLE company (
    code VARCHAR(100),                    
    title VARCHAR(255) PRIMARY KEY,                         
    industry VARCHAR(100),                              
    vertical VARCHAR(100),                             
    canton VARCHAR(100),                                
    spin_offs TEXT,                                     
    city VARCHAR(100),
    year INT,                                            
    highlights TEXT,                                   
    gender_ceo VARCHAR(50),                             
    oob BOOLEAN,                                        
    funded BOOLEAN,                                     
    comment TEXT,                                       
    gender_ceo_female TINYINT(1),                       
    oob_binary TINYINT(1),                              
    funded_binary TINYINT(1)                           
);


CREATE TABLE deal (
    id VARCHAR(100) PRIMARY KEY,                        
    investors TEXT,                                     
    amount DECIMAL(18, 2),                              
    valuation DECIMAL(18, 2),                           
    comment TEXT,
    url VARCHAR(500),
    confidential BOOLEAN,                               
    amount_confidential BOOLEAN,
    date_of_funding_round DATE,
    type VARCHAR(100),                                  
    phase VARCHAR(100),                                 
    canton VARCHAR(50),
    company VARCHAR(255), 
    gender_ceo VARCHAR(50),     
    gender_ceo_female TINYINT(1),      
    confidential_binary TINYINT(1),
    amount_confidential_binary TINYINT(1), 
    FOREIGN KEY (company) REFERENCES company(title)
        ON DELETE CASCADE
        ON UPDATE CASCADE
);